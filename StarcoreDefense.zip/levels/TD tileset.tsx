<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="tileset" tilewidth="48" tileheight="48" tilecount="13" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="48" height="48" source="../assets/images/tiles/0.png"/>
 </tile>
 <tile id="1">
  <image width="48" height="48" source="../assets/images/tiles/1.png"/>
 </tile>
 <tile id="2">
  <image width="48" height="48" source="../assets/images/tiles/2.png"/>
 </tile>
 <tile id="3">
  <image width="48" height="48" source="../assets/images/tiles/3.png"/>
 </tile>
 <tile id="4">
  <image width="48" height="48" source="../assets/images/tiles/4.png"/>
 </tile>
 <tile id="5">
  <image width="48" height="48" source="../assets/images/tiles/5.png"/>
 </tile>
 <tile id="6">
  <image width="48" height="48" source="../assets/images/tiles/6.png"/>
 </tile>
 <tile id="7">
  <image width="48" height="48" source="../assets/images/tiles/7.png"/>
 </tile>
 <tile id="8">
  <image width="48" height="48" source="../assets/images/tiles/8.png"/>
 </tile>
 <tile id="9">
  <image width="48" height="48" source="../assets/images/tiles/9.png"/>
 </tile>
 <tile id="10">
  <image width="48" height="48" source="../assets/images/tiles/10.png"/>
 </tile>
 <tile id="11">
  <image width="48" height="48" source="../assets/images/tiles/11.png"/>
 </tile>
 <tile id="12">
  <image width="48" height="48" source="../assets/images/tiles/12.png"/>
 </tile>
 <wangsets>
  <wangset name="Unnamed Set" type="mixed" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="4" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="5" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="6" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="7" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="8" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="9" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="10" wangid="0,0,0,0,0,1,0,0"/>
  </wangset>
 </wangsets>
</tileset>
